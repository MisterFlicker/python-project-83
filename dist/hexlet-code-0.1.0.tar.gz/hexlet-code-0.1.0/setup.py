# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['page_analyzer', 'page_analyzer.scripts']

package_data = \
{'': ['*'], 'page_analyzer': ['templates/*']}

install_requires = \
['Flask>=2.3.2,<3.0.0',
 'beautifulsoup4>=4.12.2,<5.0.0',
 'flake8>=6.0.0,<7.0.0',
 'gunicorn>=20.1.0,<21.0.0',
 'psycopg2-binary>=2.9.6,<3.0.0',
 'python-dotenv>=1.0.0,<2.0.0',
 'requests>=2.31.0,<3.0.0',
 'validators>=0.20.0,<0.21.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Andrey',
    'author_email': 'lutecequantum@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
